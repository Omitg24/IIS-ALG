package Session_6;

/**
 * Titulo: Clase ColoracionMapaPruebas
 *
 * @author Omar Teixeira, UO281847
 * @version 18 mar 2022
 */
public class ColoracionMapaPruebas {

	/**
	 * M�todo main
	 * @param args
	 */
	public static void main(String[] args) {
		new ColoracionMapa();
	}

}
