package Session_7;

/**
 * Titulo: Clase LevenshteinPruebas
 *
 * @author Omar Teixeira, UO281847
 * @version 28 mar 2022
 */
public class LevenshteinPruebas {

	/**
	 * M�todo main
	 * @param args
	 */
	public static void main(String[] args) {
		new Levenshtein("BARCAZAS", "ABRACADABRA");
	}
}